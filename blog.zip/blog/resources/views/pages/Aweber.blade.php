<?php
require_once app_path()."/Libraries/aweber/aweber_api.php";

// Step 1: assign these values from https://labs.aweber.com/apps
$consumerKey = 'AkOBt52Zq3qNeYY7Lt0zxkaC';
$consumerSecret = 'StEZlKltCk9pKW4qrVXL393GStprnMyUl6KkCHzG';

$aweber = new AWeberAPI($consumerKey, $consumerSecret);
if (empty($_COOKIE['accessToken'])) {
    if (empty($_GET['oauth_token'])) {
        $callbackUrl = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        list($requestToken, $requestTokenSecret) = $aweber->getRequestToken($callbackUrl);
        setcookie('requestTokenSecret', $requestTokenSecret);
        setcookie('callbackUrl', $callbackUrl);
        header("Location: {$aweber->getAuthorizeUrl()}");
        exit();
    }
    $aweber->user->tokenSecret = $_COOKIE['requestTokenSecret'];
    $aweber->user->requestToken = $_GET['oauth_token'];
    $aweber->user->verifier = $_GET['oauth_verifier'];
    list($accessToken, $accessTokenSecret) = $aweber->getAccessToken();
    setcookie('accessToken', $accessToken);
    setcookie('accessTokenSecret', $accessTokenSecret);
    header('Location: '.$_COOKIE['callbackUrl']);
    exit();
}
# set this to true to view the actual api request and response

$aweber->adapter->debug = false;
$account = $aweber->getAccount($_COOKIE['accessToken'], $_COOKIE['accessTokenSecret']);
/*echo"<pre>";
print_r($account);
exit;*/

# Code example for finding a list by its name

try {
    //$lists = $account->lists->find();
echo"<pre>";

print_r($account->lists);
echo"dfd";
exit;
    $lists = $account->lists->find(array('name' => 'Big Money Mastermind FB Campaign'));
    if(count($lists)) {
        $list = $lists[0];
        echo "FOUND list {$list->name} at {$list->self_link}\n";

    } else {
        echo "Did not find list";
    }

} catch(AWeberAPIException $exc) {
    print "<h3>AWeberAPIException:</h3>";
    print " <li> Type: $exc->type              <br>";
    print " <li> Msg : $exc->message           <br>";
    print " <li> Docs: $exc->documentation_url <br>";
    print "<hr>";
}
exit;
// Code sample for showing all broadcasts on a List.
exit;
try {
    $account = $aweber->getAccount($accessKey, $accessSecret);
    $lists = $account->lists->find(array('name' => 'Big Money Mastermind FB Campaign'));

} catch(AWeberAPIException $exc) {
    print "<h3>AWeberAPIException:</h3>";
    print " <li> Type: $exc->type              <br>";
    print " <li> Msg : $exc->message           <br>";
    print " <li> Docs: $exc->documentation_url <br>";
    print "<hr>";
}

if(!count($lists)) {
    echo "Did not find list";
    exit();
}
$list = $lists[0];
/*echo"<pre>";
print_r($list->campaigns);*/

// Search for all campaigns that are broadcasts printing both
// the sent date and subject of each broadcast
$campaign = $list->campaigns->find(array('campaign_type' => 'f'));
echo"<pre>";
print_r($campaign);
foreach($campaign as $broadcast) {
    echo "<li> {$broadcast->sent_at} : {$broadcast->subject} \n";

}

exit;









try {
    
    $listURL = "/accounts/436611/lists/4165195";
    $list = $account->loadFromUrl($listURL);
echo"<pre>";
print_r($list->subscribers);
exit;

    # create a subscriber
    $params = array(
        'email' => 'tosifqureshi@cdnsol.com',
        'ip_address' => '127.0.0.1',
        'ad_tracking' => 'client_lib_example',
        'misc_notes' => 'my cool app',
        'name' => 'John Doe',
        'custom_fields' => array(
            'Car' => 'Ferrari 599 GTB Fiorano',
            'Color' => 'Red',
        ),
        'tags' => array('cool_app', 'client_lib', 'other_tag'),
    );
    $subscribers = $list->subscribers;
    $new_subscriber = $subscribers->create($params);

    # success!
    print "A new subscriber was added to the $list->name list!";

} catch(AWeberAPIException $exc) {
    print "<h3>AWeberAPIException:</h3>";
    print " <li> Type: $exc->type              <br>";
    print " <li> Msg : $exc->message           <br>";
    print " <li> Docs: $exc->documentation_url <br>";
    print "<hr>";
    exit(1);
}


exit;






echo"<pre>";
print_r($account->data['id']);
//get all list
try {
    $list = $account->loadFromUrl('/accounts/436611/lists');
} catch (AWeberAPIException $exc) {
    print "<li> $exc->type on $exc->url, refer to $exc->message for more info ...<br>";
}
//get list using id
try {
    $listId = $account->loadFromUrl('/accounts/436611/lists/4165195');
} catch (AWeberAPIException $exc) {
    print "<li> $exc->type on $exc->url, refer to $exc->message for more info ...<br>";
}
//get list of subscriber in a list
try {
    $listsubscribers = $account->loadFromUrl('/accounts/436611/lists/4165195/subscribers');
} catch (AWeberAPIException $exc) {
    print "<li> $exc->type on $exc->url, refer to $exc->message for more info ...<br>";
}
//get list of subscriber in a list
//https://api.aweber.com/1.0/accounts/<account_id>/lists/<list_id>/broadcasts


try {
    $broadcasts = $account->loadFromUrl('/accounts/436611/lists/4134762/broadcasts?status=draft');
} catch (AWeberAPIException $exc) {
    print "<li> $exc->type on $exc->url, refer to $exc->message for more info ...<br>";
}
echo"<pre>";
print_r($broadcasts);
exit;
/*try {

URL: https://api.aweber.com/1.0/accounts/<account_id>/lists/<list_id>/broadcasts?status=<status>


    $resource = $account->loadFromUrl('/accounts/436611//lists/4045928/subscribers');
} catch (AWeberAPIException $exc) {
    print "<li> $exc->type on $exc->url, refer to $exc->message for more info ...<br>";
}*/
echo"dsd";

try {
    $resource = $account->loadFromUrl('/accounts/436611//lists/4045928/subscribers');
} catch (AWeberAPIException $exc) {
    print "<li> $exc->type on $exc->url, refer to $exc->message for more info ...<br>";
}
exit;
$AWeberCollection = new AWeberCollection();
echo"<pre>";
print_r($AWeberCollection);
exit;
$u = $aweber->find(array('email' => 'aibek82@gmail.com'));
echo"<pre>";
print_r($u);
exit;
/*$account = $aweber->create($_COOKIE['accessToken'], $_COOKIE['accessTokenSecret']);*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>AWeber Test Application</title>
  <link type="text/css" rel="stylesheet" href="styles.css" />
<body>
<?php
foreach($account->lists as $offset => $list) {
?>
<h1>List: <?php echo $list->name; ?></h1>
<h3><?php echo $list->id; ?></h3>
<table>
  <tr>
    <th class="stat">Subject</th>
    <th class="value">Sent</th>
    <th class="value">Stats</th>
  </tr>
<?php

foreach($list->campaigns as $campaign) {
    if ($campaign->type == 'broadcast_campaign') {
?>
    <tr>
        <td class="stat"><em><?php echo $campaign->subject; ?></em></td>
        <td class="value"><?php echo date('F j, Y h:iA', strtotime($campaign->sent_at)); ?></td>
        <td class="value"><ul>
              <li><b>Opened:</b> <?php echo $campaign->total_opens; ?></li>
              <li><b>Sent:</b>  <?php echo $campaign->total_sent; ?></li>
              <li><b>Clicked:</b>  <?php echo $campaign->total_clicks; ?></li>
            </ul>
        </td>
    <?php
    }
} ?>
</table>
<?php }
?>
<body>
</html>
