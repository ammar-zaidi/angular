<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AutoresponderDetails extends Model
{
    //
    protected $table="autoresponder_details";
}
