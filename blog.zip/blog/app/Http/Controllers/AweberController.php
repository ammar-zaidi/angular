<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Libraries\aweber\AWeberException;
use App\Libraries\aweber\AWeberOAuthAdapter;
use App\Libraries\aweber\OAuthServiceProvider;
use App\Libraries\aweber\ArrayAccess;
use App\Libraries\aweber\Iterator;
use App\Libraries\aweber\Countable;
use App\Libraries\aweber\AWeberServiceProvider;
use App\Libraries\aweber\AWeberAPIBase;
use App\Libraries\aweber\AWeberResponse;
use App\Libraries\aweber\AWeberCollection;
use App\Libraries\aweber\AWeberEntry;
use App\Libraries\aweber\AWeberAPI;

use App\Libraries\aweber\CurlObject;
use App\Libraries\aweber\CurlResponse;
use App\Libraries\aweber\AWeberEntryDataArray;
use App\Autoresponder;
use App\UserAutoresponder;
use App\AutoresponderDetails;
//require_once('././exceptions.php');





class AweberController extends Controller
{

public function view(){
    return view()->first(
    ['custom-template', 'pages.Aweber']
);
}
    public function index()
    {
       // echo app_path();
       // require app_path().'/includes/vendor/autoload.php';
      //  exit;
    
   // new \App\Libraries\aweber\AWeberAPI;
      /*$consumerKey= env("aweberconsumerKey");
	  $consumerSecret= env("aweberconsumerSecret");*/
	 $consumerKey = 'AkOBt52Zq3qNeYY7Lt0zxkaC';
    $consumerSecret = 'StEZlKltCk9pKW4qrVXL393GStprnMyUl6KkCHzG';

$aweber = new AWeberAPI($consumerKey, $consumerSecret);	  


 $UserAutoresponder=  UserAutoresponder::with('auto_detail')->where([
               'user_id' => "1",
               'autoresponder_id' => "1", 
            ])->get();

/*echo"<pre>";
print_r(count($UserAutoresponder[0]->auto_detail));exit;*/
	  /*if (empty($_COOKIE['accessToken']) && count($UserAutoresponder[0]->auto_detail)=='0') {*/
      if (count($UserAutoresponder[0]->auto_detail)=='0') {
    if (empty($_GET['oauth_token'])) {
        $callbackUrl = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
         $a=list($requestToken, $requestTokenSecret) = $aweber->getRequestToken($callbackUrl);
        
        setcookie('requestTokenSecret', $requestTokenSecret);
        setcookie('callbackUrl', $callbackUrl);
        header("Location: {$aweber->getAuthorizeUrl()}");
        exit();
    }
    $aweber->user->tokenSecret = $_COOKIE['requestTokenSecret'];
    $aweber->user->requestToken = $_GET['oauth_token'];
    $aweber->user->verifier = $_GET['oauth_verifier'];
    list($accessToken, $accessTokenSecret) = $aweber->getAccessToken();
    setcookie('accessToken', $accessToken);
    setcookie('accessTokenSecret', $accessTokenSecret);

   /* $AutoresponderDetails = new AutoresponderDetails;

    $AutoresponderDetails->app_id = "1";
    $AutoresponderDetails->user_autoresponder_id = "1";
    $AutoresponderDetails->accessToken = $accessToken;
    $AutoresponderDetails->accessTokenSecret = $accessTokenSecret;*/


    $data=  AutoresponderDetails::insert([
               'app_id' => "1",
               'user_autoresponder_id' => "1",
               'accessToken' => $accessToken,
               'accessTokenSecret'=>$accessTokenSecret,
               
            ]);

   // $AutoresponderDetails->app_id = $request->name;
    //header('Location: '.$_COOKIE['callbackUrl']);
    exit();
}
# set this to true to view the actual api request and response
/*echo $_COOKIE['accessToken'];
echo  $_COOKIE['accessTokenSecret'];*/
$aweber->adapter->debug = false;

$account = $aweber->getAccount($UserAutoresponder[0]->auto_detail->accessToken, $UserAutoresponder[0]->auto_detail->accessTokenSecret);

# Code example for finding a list by its name

try {
   



$HTTP_METHOD = 'GET';
$URL = "/accounts/436611/lists/4165195/subscribers";
$PARAMETERS = array();
$RETURN_FORMAT = array();
 
$resp = $aweber->adapter->request($HTTP_METHOD, $URL, $PARAMETERS, $RETURN_FORMAT);
// print_r($resp); // debugging
 echo"<pre>";
 print_r($resp);
 exit;
$broadcast_id =  $resp['broadcast_id']; // we will be using this $broadcast_id in example 5
print "BC: $broadcast_id\n\n"; 
exit;





$HTTP_METHOD = 'POST';
$URL = "/accounts/436611/lists/4165195/broadcasts";
$PARAMETERS = array(
    'subject' => 'BC created via API',
    'body_html' => 'This is the html body',
    'body_text' => 'This is the text body',
    
 );
$RETURN_FORMAT = array();
 
$resp = $aweber->adapter->request($HTTP_METHOD, $URL, $PARAMETERS, $RETURN_FORMAT);
// print_r($resp); // debugging
 
$broadcast_id =  $resp['broadcast_id']; // we will be using this $broadcast_id in example 5
print "BC: $broadcast_id\n\n"; 
exit;




   




    //$lists = $account->lists;
echo"<pre>";
 //$listURL = "/accounts/436611/lists/4165195/subscribers/55390792";
 $listURL = "/accounts/436611/lists/4165195";
    $list = $account->loadFromUrl($listURL);


 /*$listURL = "/accounts/436611/lists/4165195/broadcasts";
print_r($account->loadFromUrl($listURL));*/

// posr request

//$listURL = "/accounts/436611/lists/4165195/broadcasts";
$params = array(
        'email' => 'tosifqureshi@cdnsol.com',
        'ip_address' => '127.0.0.1',
        'ad_tracking' => 'client_lib_example',
        'misc_notes' => 'my cool app',
        'name' => 'John Doe',
        'custom_fields' => array(
            'Car' => 'Ferrari 599 GTB Fiorano',
            'Color' => 'Red',
        ),
        'tags' => array('cool_app', 'client_lib', 'other_tag'),
    );
 $subscribers = $list->subscribers;
 echo"<pre>";
 print_r($subscribers);
 exit;
    $new_subscriber = $subscribers->create($params);
//print_r($account->create($params));




exit;
    $lists = $account->lists->find(array('name' => 'Big Money Mastermind FB Campaign'));
    if(count($lists)) {
        $list = $lists[0];
        echo "FOUND list {$list->name} at {$list->self_link}\n";

    } else {
        echo "Did not find list";
    }

} catch(AWeberAPIException $exc) {
    print "<h3>AWeberAPIException:</h3>";
    print " <li> Type: $exc->type              <br>";
    print " <li> Msg : $exc->message           <br>";
    print " <li> Docs: $exc->documentation_url <br>";
    print "<hr>";
}
exit;
       
    }



	
}
?>
