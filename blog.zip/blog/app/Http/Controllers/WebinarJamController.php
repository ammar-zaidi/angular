<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Libraries\webinarjam\WebinarJam;

class WebinarJamController extends Controller
{

    public function index()
    {
      $getresponse = new WebinarJam("78ed2bffae66770691ed5c5278e5664271e2de538bbb232d3ae1b7b6d4a14195");
      echo"<pre>";
     // print_r($getresponse);
      
      $getWebinars=$getresponse->getWebinars();
		//print_r($getWebinars);


    $getWebinar=$getresponse->getWebinar('cd92276373');
   // print_r($getWebinar);
      



      $addToWebinar=$getresponse->addToWebinar('7f2f5bc6d4','tosif','ammarzaidi@cdnsol.com',0);
    print_r($addToWebinar);
      exit;
    }
	
}
?>
