<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Libraries\getresponse\GetResponse;

class CampaignController extends Controller
{

    public function index($timezone)
    {
        echo Carbon::now($timezone)->toDateTimeString();
    }
	public function timezones()
    {
		$getresponse = new GetResponse("a9a50fae28c3b208849a8c9dbbac2fbb");
		$getresponse->enterprise_domain = 'https://legendarymarketer.com/';
		//$getresponse->api_url = 'https://api3.getresponse360.com/v3'; //default
		//echo"<pre>";
		//print_r($getresponse);
		//List all Campaigns
		$getCampaigns = $getresponse->getCampaigns();
		echo"<pre>";
		print_r($getCampaigns);



		//exit;
		$getWebForms = $getresponse->getWebForms(array(
	'query' => array(
		'campaignId' => '6nWaF',
	)
));
		echo"<pre>";
		print_r($getWebForms);
		exit;
		
		
		//Create  Campaigns
		/*$createCampaign = $getresponse->createCampaign(array(
			'name'              =>  'legenderymarketer',
		));*/
		
		//Add contact
		/*$addContact=$getresponse->addContact(array(
			'name'              => 'Tosif Qureshi',
			'email'             => 'ammarzaidi@cdnsol.com',
			'dayOfCycle'        => 0,
			'campaign'          => array('campaignId' => '6Tlcn'),
			'ipAddress'         => $_SERVER['REMOTE_ADDR']
		));	
		exit;*/
		
		//returns collection of CONTACTS resources.
		//$getContacts = $getresponse->getContacts();
		
		// get specific column of Contacts
		/*$getContactsbycolumn = $getresponse->getContacts(array(			
			'fields' => 'name,email'
		));
*/
		//search contact
		/*$contactsearch = $getresponse->getContacts(array(
			'query' => array(
				'email' => 'tosifqureshi@cdnsol.com',
			),
			'fields' => 'name,email'
*/
		
		//This method creates and queues sending a new newsletter.
		/*$result = $getresponse->sendNewsletter(array(
				"subject" => 'Test subject',
				"fromField" => array('fromFieldId' => 'V'),
				"content" => array(
					'html' => 'Test newsletter contetnt.'
				),
				 "campaign" => array(
        'campaignId'=> '6Tlz9'
    ),
				"sendSettings" => array(
					"selectedContacts" => array('6Tlz9')
			)
    ));
    echo"<pre>";
    print_r($result);
    exit;*/
    
    $postautoresponders = $getresponse->postautoresponders(array(
    "name" => "BUILD12345",
    "subject" => "test12",
    "status" => "disabled",
 "content"=> array(
        "plain"=> null,
        "html"=> "<h1>test 12</h1><p>Some test</p>"
    ),
        "sendSettings"=> array(
        "type"=>  "delay",
        "delayInHours"=>  "21",
        "sendAtHour"=>  null,
        "recurrence"=>  "false",
        "timeTravel"=>  "false",
        "excludedDaysOfWeek"=>  [
            "Monday",
            "Tuesday",
            "Thursday",
            "Sunday"
        ]
    ),
     "triggerSettings"=> array(
        "type"=> "onday",
        "dayOfCycle"=> "13",
        "selectedCampaigns"=> [
            "6Tlcn"
        ]
    )
));
		
		echo"<pre>";
		print_r($postautoresponders);
		exit;
		
	/*	$result = $getresponse->sendNewsletter(array(
				"subject" => 'Test subject',
				"fromField" => array('fromFieldId' => 'V'),
				"content" => array(
					'html' => 'Test newsletter contetnt.'
				),
				"sendSettings" => array(
					"selectedContacts" => array('64bAz')
			)
    ));
    echo"<pre>";
    print_r($result);
    exit;
		

$getNewsletter = $getresponse->getNewsletter();
		echo"<pre>";
		print_r($getNewsletter);
		exit;
	
		exit;*/
		/*	$result = $getresponse->getContacts(array(
	'query' => array(
		'email' => 'ammarzaidi@cdnsol.com',
	),
	'fields' => 'name,email'
));*/
$getNewsletter = $getresponse->getNewsletter();
echo"<pre>";
//print_r($getNewsletter);
$getAutoresponder = $getresponse->getAutoresponder();
$getAutoresponderstatistics = $getresponse->getAutoresponderstatistics(array(
	'query' => array(
		'autoresponderId' => 'yjwSz',
	)
));
$getAutoresponderthumbnail = $getresponse->getAutoresponderthumbnail();
/*echo"<pre>";
print_r($getAutoresponder);
echo"<pre>";
print_r($getAutoresponderthumbnail);*/


/*$postautoresponders = $getresponse->postautoresponders(array(
    "autoresponderId" => "yjwSz",
    "subject" => "test12",
    "status" => "disabled",
    "campaignId" => "64bAz",
        "sendSettings": '{
        "type": "delay",
        "delayInHours": "21",
        "sendAtHour": null,
        "recurrence": "false",
        "timeTravel": "false",
        "excludedDaysOfWeek": [
            "Monday",
            "Tuesday",
            "Thursday",
            "Sunday"
        ]
    }',
));*/
/*echo"<pre>";
echo"<pre>";
print_r($postautoresponders);
exit;*/

exit;
/*$result1 = $getresponse->addContact(array(
    'name'              => 'Jon Smith',
    'email'             => 'ammarzai@gmail.com',
    'dayOfCycle'        => 0,
   
    'ipAddress'         => '89.206.31.190',
  
));*/
//print_r($result);
/*$result = $getresponse->sendNewsletter(array(
				"subject" => 'Test subject',
				"fromField" => array('fromFieldId' => 'from_field_id'),
				"content" => array(
					'html' => 'Test newsletter contetnt.'
				),
				"sendSettings" => array(
					"selectedContacts" => array('64bAz')
			)
    ));*/
    //$result1 = $getresponse->deleteContact("gcL1Tz");
		exit;
        echo Carbon::now($timezone)->toDateTimeString();
    }
}
?>
