<?php $__env->startSection('content'); ?>
<div class="">

    <div class="row">

        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Customer Orders</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Product</th>
                                <th>Image</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                                
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php if(count($orders)): ?>
                            <?php $total=0; ?>
                            <?php $__currentLoopData = $orders[0]->orderdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $total=$total+$row->sub_total; ?>
                            <tr>
                                <td><?php echo e($row->order_number_detail); ?></td>
                                <td><?php echo e($row->orderdetailproduct->product_name); ?></td>
                                <td><img src="<?php echo e(asset('uploads')); ?>/<?php echo e($row->orderdetailproduct->product_image); ?>" class="img-thumbnail img-responsive" style="width: 100px;"></td>
                                <td><?php echo e($row->quantity); ?></td>
                                <td><?php echo e($row->price); ?></td>
                                <td><?php echo e($row->sub_total); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="5" style="text-align: right;"><b>Total:<?php echo e($total); ?></b></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>